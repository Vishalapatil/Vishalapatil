var objRefrance;
var name = prjName;
var ddlcityId = 0;
var objPremium = new Object();
var objPorduct = new Object();
var objSpotProduct = new Object();
var objCopySpotProduct = new Object();

liveratessocket.on('connect', function () {
	if(liveratessocket.connected==true){
    liveratessocket.emit('room', name);  
    }
});

adminsocket.on("ClientData", function(data) {
    try {
        if (data != "") {
            objRefrance = JSON.parse(data);
        }
    } catch (e) {

    }
});


liveratessocket.on('message', function(data) {
    if (data != "") {
        localStorage.setItem("GeneralPremium_data", JSON.stringify(objPorduct));
        try {
            var objGenPremium = localStorage.getItem("GeneralPremium_data");
            objPremium = JSON.parse(objGenPremium);
        } catch (e) {

        }
        let liverates = data;
        let rates = data.Rate;
       

        let htmlproduct = "";
		let htmlproductslr = "";
        let htmlHd = "";
       
        let BuyDisplay = "";
        let SellDisplay = "";
        let HighDisplay = "";
        let LowDisplay = "";
        let Backslace = "";
        let htmlStock = "";
        let BuyTDDisplay = "";
        let SellTDDisplay = "";
        if (objCLientDetail != undefined) {


            if (objCLientDetail.RateDisplay == true) {
                var html = '';
                if (objCLientDetail.BuyRate == false) { BuyDisplay = "display:none" }
                if (objCLientDetail.SellRate == false) { SellDisplay = "display:none" }
                if (objCLientDetail.HighRate == false) { HighDisplay = "display:none"; }
                if (objCLientDetail.LowRate == false) { LowDisplay = "display:none"; }
                if (objCLientDetail.HighRate == true && objCLientDetail.LowRate == true) { Backslace = "/"; }
                if (objCLientDetail.BuyRate == false && objCLientDetail.LowRate == false) { BuyTDDisplay = "display:none"; }
                if (objCLientDetail.SellRate == false && objCLientDetail.HighRate == false) { SellTDDisplay = "display:none"; }
                if ($.grep(rates, function(x) { return x.IsDisplay == "True" }).length > 0) {
                    

                    htmlHd += '<table class="table">'+
                    '   <tbody>'+
                    '      <tr class="product-title-color">'+
                    '         <td class="p-h p0"><span>PRODUCT</span></td>'+
                    '         <td class="p-h ph" style="' + BuyDisplay + '"><span>BUY</span></td>'+
                    '         <td class="p-h ph" style="' + SellDisplay + '"><span>SELL</span></td>'+
                    '         <td class="p-h ph smr"><span>HIGH / LOW</span></td>' +
                    '         <td class="p-h ph smr"><span></span></td>' +
                    '      </tr>'+
                    '   </tbody>'+
                    '</table>';
                }
                try {
                    for (let i = 0; i < rates.length; i++) {
                        let sname = rates[i].Symbol;
                        let bid = rates[i].Bid;
                        let ask = rates[i].Ask;
                        let high = rates[i].High;
                        let low = rates[i].Low;
                        let src = rates[i].Source.toLocaleLowerCase();
                        let stock = rates[i].Stock;
                        let IsDisplayFront = rates[i].IsDisplay;
                        if (IsDisplayFront.toLocaleLowerCase() == "true") {

                            let bgcolor_class_bid = "";
                            let bgcolor_class_ask = "";
                            try {

                                if (bid == objPremium[i + 'Bid']) {
                                    bgcolor_class_bid = 'e';
                                } else if (bid >= objPremium[i + 'Bid']) {
                                    bgcolor_class_bid = 'h';
                                    objPorduct[i + 'Bid'] = bid
                                } else if (bid <= objPremium[i + 'Bid']) {
                                    bgcolor_class_bid = 'l';
                                    objPorduct[i + 'Bid'] = bid
                                } else {
                                    objPorduct[i + 'Bid'] = bid;
                                    bgcolor_class_bid = 'e';
                                }
                            } catch (e) {}

                            try {
                                if (ask == objPremium[i + 'Ask']) {
                                    bgcolor_class_ask = 'e';
                                } else if (ask >= objPremium[i + 'Ask']) {
                                    bgcolor_class_ask = 'h';
                                    objPorduct[i + 'Ask'] = ask
                                } else if (ask <= objPremium[i + 'Ask']) {
                                    bgcolor_class_ask = 'l';
                                    objPorduct[i + 'Ask'] = ask
                                } else {
                                    objPorduct[i + 'Ask'] = ask;
                                    bgcolor_class_ask = 'e';
                                }
                            } catch (e) {}

                            

                            if (src=='gold') {      
                                htmlproduct +=  '<div class="col-md-6 col-sm-6 col-xs-12">'+
                                '<div  style="font-family: calibri;" id="tblLiveRates">'+
                                    '                    <div class="imggold">'+
                                    '                        <img alt="Gold" src="images/goldnew.png" class="img-responsive goldimgwidth">'+
                                    '                    </div>'+
                                    '                    <div class="part1table">'+
                                    '                        <div class="tabletitle table1borderbottom"><span id="GoldSymbol">' + sname + '</span></div>'+
                                    '                        <div class="buyyingwidth">'+
                                    '                            <div class="sellingrate">SELLING RATE</div>'+
                                    '                            <div class="rate" style="' + SellDisplay + '">'+
                                    '                                <img src="images/currency.png" class="inr">'+
                                    '                                <span><span class="ratefont ' + bgcolor_class_ask + '" id="GoldSell">' + ask + '</span></span>'+
                                    '                            </div>'+
                                    '                        </div>'+
                                    '                        <div class="highlowrate">'+
                                    '                            <div style="' + LowDisplay + '">'+
                                    '                                <span id="GoldLow" class="red" style="">' + low + '</span>'+
                                    '                                <div class="highlowtext red">(Low)</div>'+
                                    '                            </div>'+
                                    ''+
                                    '                            <div style= "' + HighDisplay + '">'+
                                    '                                <span id="GoldHigh" class="green" style="">' + high + '</span>'+
                                    '                                <div class="highlowtext green" style="">(High)</div>'+
                                    '                            </div>'+
                                    '                        </div>'+
                                    '                        <div class="clearfix"></div>'+
                                    '                        '+
                                    '                    </div>'+
                                    '                    </div>'+
                                    '                </div>';
                            }
                            if (src == 'silver') {
                                htmlproductslr +=   '<div class="col-md-6 col-sm-6 col-xs-12">'+
                                   '<div  style="font-family: calibri;width:100%;float:left;" id="tblLiveRates">' +
                                    '                    <div class="imggold">' +
                                    '                        <img alt="Gold" src="images/silvernew.png" class="img-responsive goldimgwidth">' +
                                    '                    </div>' +
                                    '                    <div class="part1table">' +
                                    '                        <div class="tabletitle table1borderbottom"><span id="GoldSymbol">' + sname + '</span></div>' +
                                    '                        <div class="buyyingwidth">' +
                                    '                            <div class="sellingrate">SELLING RATE</div>' +
                                    '                            <div class="rate" style="' + SellDisplay + '">' +
                                    '                                <img src="images/currency.png" class="inr">' +
                                    '                                <span><span class="ratefont ' + bgcolor_class_ask + '" id="GoldSell">' + ask + '</span></span>' +
                                    '                            </div>' +
                                    '                        </div>' +
                                    '                        <div class="highlowrate">' +
                                    '                            <div style="' + LowDisplay + '">' +
                                    '                                <span id="GoldLow" class="red" style="' + SellDisplay + '">' + low + '</span>' +
                                    '                                <div class="highlowtext red">(Low)</div>' +
                                    '                            </div>' +
                                    '' +
                                    '                            <div style="' + HighDisplay + '">' +
                                    '                                <span id="GoldHigh" class="green" style="">' + high + '</span>' +
                                    '                                <div class="highlowtext green" style="">(High)</div>' +
                                    '                            </div>' +
                                    '                        </div>' +
                                    '                        <div class="clearfix"></div>' +
                                    '                        ' +
                                    '                    </div>' +
                                    '                    </div>' +
                                    '                </div>';
                            }

                        }
                    }
                    localStorage.setItem("GeneralPremium_data", JSON.stringify(objPorduct));
                    $('#divProduct').html(htmlproduct);
                    $('#silverproduct').html(htmlproductslr);
                    $('#divHeader').html(htmlHd);
                } catch (e) {}
            } else {
                $('#tblsm').html("Live Rate currently not available");
            }
        }
    }
});

$(document).on("click", ".closeNotification", function(e) {
    $("#notificationDiv").html("");
});

document.onkeydown = function(evt) {
    evt = evt || window.event;
    if (evt.keyCode == 9) {
        $("#notificationDiv").html("");
    }
};


liveratessocket.on('Liverate', function(data) {
    let objrates = data;
    let viewSymbole = "gold,silver,goldnext,silvernext,xauusd,xagusd,inrspot"
    let futurehtml = '';
    let spothtml = '';
    let nexthtml = '';
    let futurehtmlHD = '';
    let futureHD = true;
    let spothtmlHD = '';
    let spotHD = true;
    let nexthtmlHD = '';
    let nextHD = true;

    try {
        localStorage.setItem("Spot_data", JSON.stringify(objSpotProduct));
        try {
            var SpotProduct_data = localStorage.getItem("Spot_data");
            objCopySpotProduct = JSON.parse(SpotProduct_data);
        } catch (e) {

        }

        for (let i = 0; i < objrates.length; i++) {
            let symbole = objrates[i]["symbol"];
            let ObjSymbole = $.grep(objRefrance, function(v) {
                return v.Source.toLowerCase() == symbole.toLowerCase();
            });
            let s = objrates[i]["symbol"].toLowerCase()

            if (ObjSymbole.length > 0) {



                let ref_class_bid = "";
                let ref_class_ask = "";
                try {

                    if (objrates[i]["Bid"] == objCopySpotProduct[i + 'Bid']) {
                        ref_class_bid = 'e';
                    } else if (objrates[i]["Bid"] >= objCopySpotProduct[i + 'Bid']) {
                        ref_class_bid = 'h';
                        objSpotProduct[i + 'Bid'] = objrates[i]["Bid"]
                    } else if (objrates[i]["Bid"] <= objCopySpotProduct[i + 'Bid']) {
                        ref_class_bid = 'l';
                        objSpotProduct[i + 'Bid'] = objrates[i]["Bid"]
                    } else {
                        objSpotProduct[i + 'Bid'] = objrates[i]["Bid"];
                        ref_class_bid = 'e';
                    }
                } catch (e) {}

                try {
                    if (objrates[i]["Ask"] == objCopySpotProduct[i + 'Ask']) {
                        ref_class_ask = 'e';
                    } else if (objrates[i]["Ask"] >= objCopySpotProduct[i + 'Ask']) {
                        ref_class_ask = 'h';
                        objSpotProduct[i + 'Ask'] = objrates[i]["Ask"]
                    } else if (objrates[i]["Ask"] <= objCopySpotProduct[i + 'Ask']) {
                        ref_class_ask = 'l';
                        objSpotProduct[i + 'Ask'] = objrates[i]["Ask"]
                    } else {
                        objSpotProduct[i + 'Ask'] = objrates[i]["Ask"];
                        ref_class_ask = 'e';
                    }
                } catch (e) {}


                if (ObjSymbole[0].IsDisplay == true) {

                    if (symbole.toLocaleLowerCase() == "gold" || symbole.toLocaleLowerCase() == "silver") {
                        if (futureHD == true) {
                            futureHD = false;
                            futurehtmlHD += '<table class="prodict-title hed">' +
                                '   <tbody>' +
                                '      <tr>' +
                                '         <td class="mtw1 product-size b1"><span>FUTURE</span></td>' +
                                '         <td class="mtw2 product-size b2 text-center"><span>BUY</span></td>' +
                                '         <td class="mtw2 product-size b2 text-center"><span>SELL</span></td>' +
                                '         <td class="mtw2 product-size b2 text-center sm"><span>HIGH</span></td>' +
                                '         <td class="mtw2 product-size b2 text-center sm"><span>LOW</span></td>' +
                                '      </tr>' +
                                '   </tbody>' +
                                '</table>';
                        }
                        

                        futurehtml += '<div class="col-md-6">'+
                        '                               <div class="ftcvr">'+
                        '                               <div class="future">' + ObjSymbole[0].Symbol_Name + '</div>'+
                                               '                                    <div  class="futuremainrate"><span id="GoldMcxBuy" class="' + ref_class_bid + '">' + objrates[i]["Bid"] + '</span>  <span class="bidask">BID</span></div>'+
                                               '                                    <div  class="futuremainrate"><span id="GoldMcxSell" class="' + ref_class_ask + '">' + objrates[i]["Ask"] + '</span>  <span class="bidask">ASK</span></div>'+
                        '                                <div>'+
                        '                                    <div class="futuhigh"><span id="GoldMcxLow" class="red">' + objrates[i]["Low"] + '</span>  <span class="futurehihgtext red">Low</span></div>'+
                        '                                    <div class="futuhigh"><span id="GoldMcxHigh" class="green">' + objrates[i]["High"] + '</span>  <span class="futurehihgtext green">High</span></div>'+
                        '                                </div>'+
                        '                                </div>'+
                        '                                </div>';


                    } else if (symbole.toLocaleLowerCase() == "xauusd" || symbole.toLocaleLowerCase() == "xagusd" || symbole.toLocaleLowerCase() == "inrspot") {
                        {
                            if (spotHD == true) {
                                spotHD = false;
                                

                                spothtmlHD += 
                                '                                <tr class="table2borderbottom thcolor">' +
                                '                                    <td class="tdbg border-top-left-radius" style="background-color: #2c84b5;"> ' +
                                '                                    </td>' +
                                '                                    <td class="spot-title thpaddingleft">' +
                                '                                        <span> BID</span>' +
                                '                                    </td>' +
                                '                                    <td class="spot-title">' +
                                '                                        <span> ASK</span>' +
                                '                                    </td>' +
                                '                                    <td class="spot-title">' +
                                '                                        <span>HIGH</span>' +
                                '                                    </td>' +
                                '                                    <td class="spot-title">' +
                                '                                        <span>LOW</span>' +
                                '                                    </td>' +
                                '                                </tr>' 
                            }
                            

                            spothtml += 
            '                                <tr class="table2borderbottom">'+
            '                                    <td class="tdbg">'+
            '                                        <span id="GoldComexSymbol">' + ObjSymbole[0].Symbol_Name + '</span>'+
            '                                    </td>'+
            '                                    <td class="thpaddingleft">'+
                              '                                        <span id="GoldComexBuy" class="' + ref_class_bid + '">' + objrates[i]["Bid"] + '</span>'+
            '                                    </td>'+
            '                                    <td>'+
                              '                                        <span id="GoldComexSell"  class="' + ref_class_ask + '">' + objrates[i]["Ask"] + '</span>'+
            '                                    </td>'+
            '                                    <td>'+
            '                                        <span id="GoldComexHigh">' + objrates[i]["High"] + '</span>'+
            '                                    </td>'+
            '                                    <td>'+
            '                                        <span id="GoldComexLow">' + objrates[i]["Low"] + '</span>'+
            '                                    </td>'+
            '                                </tr>'

                           
                        }
                    } else if (symbole.toLocaleLowerCase() == "goldnext" || symbole.toLocaleLowerCase() == "silvernext") {
                        {
                            if (nextHD == true) {
                                nextHD = false;
                              

                                nexthtmlHD += '<table class="prodict-title">'+
                                '   <tbody>'+
                                '      <tr>'+
                                '         <td class="mtw1 product-size b1"><span>NEXT</span></td>'+
                                '         <td class="mtw2 product-size b2 text-center"><span>BUY</span></td>'+
                                '         <td class="mtw2 product-size b2 text-center"><span>SELL</span></td>'+
                                '         <td class="mtw2 product-size b2 text-center sm"><span>HIGH</span></td>'+
                                '         <td class="mtw2 product-size b2 text-center sm"><span>LOW</span></td>'+
                                '      </tr>'+
                                '   </tbody>'+
                                '</table>';
                            }
                           
                            nexthtml += '<div class="col-md-6">'+
                        '                               <div class="ftcvr">'+
                        '                               <div class="future">' + ObjSymbole[0].Symbol_Name + '</div>'+
                                               '                                    <div  class="futuremainrate"><span id="GoldMcxBuy" class="' + ref_class_bid + '">' + objrates[i]["Bid"] + '</span>  <span class="bidask">BID</span></div>'+
                                               '                                    <div  class="futuremainrate"><span id="GoldMcxSell" class="' + ref_class_ask + '">' + objrates[i]["Ask"] + '</span>  <span class="bidask">ASK</span></div>'+
                        '                                <div>'+
                        '                                    <div class="futuhigh"><span id="GoldMcxLow" class="red">' + objrates[i]["Low"] + '</span>  <span class="futurehihgtext red">Low</span></div>'+
                        '                                    <div class="futuhigh"><span id="GoldMcxHigh" class="green">' + objrates[i]["High"] + '</span>  <span class="futurehihgtext green">High</span></div>'+
                        '                                </div>'+
                        '                                </div>'+
                        '                                </div>';
                        }


                    }
                }
            }
        }
        localStorage.setItem("Spot_data", JSON.stringify(objSpotProduct));
        $('#divSpotHd').html(spothtmlHD);
        $('#divSpot').html(spothtml);
        $('#divFutureHd').html(futurehtmlHD);
        $('#divFuture').html(futurehtml);
        $('#divNextHd').html(nexthtmlHD);
        $('#divNext').html(nexthtml);
    } catch (e) {
        console.log(e)
    }
});

function getParameterByName(name, url) {
    if (!url) url = window.location.href;
    name = name.replace(/[\[\]]/g, "\\$&");
    var regex = new RegExp("[?&]" + name + "(=([^&#]*)|&|#|$)"),
        results = regex.exec(url);
    if (!results) return null;
    if (!results[2]) return '';
    return decodeURIComponent(results[2].replace(/\+/g, " "));
}