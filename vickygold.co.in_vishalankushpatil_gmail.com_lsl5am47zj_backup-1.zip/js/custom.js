var apiUrl = "https://www.vickygold.co.in/";
var adminsocketurl = "https://www.vickygold.co.in:10001";
var liveratessocketurl = "https://www.vickygold.co.in:10008";
var prjName = "vickygold";
var clientId = "1";
const adminsocket = io(adminsocketurl, {

});
const liveratessocket = io(liveratessocketurl, {
});

$("#hdr").load("header.html");
$("#ftr").load("footer.html");
var isDisplayAdd = true;

adminsocket.on('connect', function() {
	if(adminsocket.connected==true){
    adminsocket.emit('Client', prjName);
	 }
});
adminsocket.on('ClientHeaderDetails', function(data) {
    try {

        if (data != "") {
            if (data.MessageType == "Header") {
                data = data["Data"];
                objCLientDetail = JSON.parse(data)[0];
                $(".bookingno1").html(objCLientDetail.BookingNo1);
                $(".bookingno2").html(objCLientDetail.BookingNo2);
                $(".bookingno3").html(objCLientDetail.BookingNo3);
                $(".bookingno4").html(objCLientDetail.BookingNo4);
                $(".bookingno5").html(objCLientDetail.BookingNo5);
                $(".bookingno6").html(objCLientDetail.BookingNo6);
                $(".bookingno7").html(objCLientDetail.BookingNo7);
                $(".address1").html(objCLientDetail.Address_client);
                $(".address2").html(objCLientDetail.Address_client2);
                $(".address3").html(objCLientDetail.Address_client3);
                $(".marquee1").html(objCLientDetail.Marquee);
                $(".marquee2").html(objCLientDetail.Marquee2);
                $(".email1").html(objCLientDetail.Email1);
                $(".email2").html(objCLientDetail.Email2);
                $(".bookingno1").html(objCLientDetail.BookingNo1);
                $(".whatsappno").html(objCLientDetail.whatsapp_no1);

                if (objCLientDetail.SYMBOL_COUNT == 0) {
                    $('#divProduct').html("<h3>Live Rate currently not available<h3>");
                    $('#divHeader').html("");
                } else if (objCLientDetail.RateDisplay == false) {
                    $('#divProduct').html("<h3>Live Rate currently not available<h3>");
                    $('#divHeader').html("");
                }
                if (objCLientDetail.BannerWeb != '' && objCLientDetail.BannerWeb != null && isDisplayAdd == true) {
                    isDisplayAdd = false;
                    $(".add-banner").css("display", "block")
                    $("#advetiseImg").attr("src", objCLientDetail.BannerWeb);
                }



                //console.log(data);
            } else if (data.MessageType == "Notification") {
                let objnotification = JSON.parse(data.Data);

                var html = '<div class="pop-up-cover" style="' +
                    '">' +
                    '  		<div class="pop">' +
                    '  		<div class="container">' +
                    '	  			<div class="col-md-4">' +
                    '	  				<div class="pop-logo">' +
                    '	  					<img src="images/web-1.png" alt="">' +
                    '	  				</div>' +
                    '	  			</div>' +
                    '	  			<div class="col-md-8">' +
                    '	  				<div class="pop-text">' +
                    '	  					<h4>' + objnotification.Title + ' ,<a href="#"><i class="fa fa-times closeNotification" aria-hidden="true"></i></a></h4>' +
                    '	  					<p>' + objnotification.Shortdesc + '</p>' +
                    '	  				</div>' +
                    '	  			</div>' +
                    '  			</div>' +
                    '  		</div>' +
                    '  	</div>';



                $("#notificationDiv").html(html);

            }

        }
    } catch (e) {

    }
});

$(document).on("click", ".closeNotification", function(e) {
    $("#notificationDiv").html("");
});
$(document).on("click", ".close", function(e) {
    $(".add-banner").removeAttr("style").hide();
});